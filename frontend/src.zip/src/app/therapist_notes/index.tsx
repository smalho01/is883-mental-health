"use client";

import React, { useState, useEffect } from 'react';
import { Button, Heading, Input } from "../../components";

interface TherapistNote {
  name: string;
  pronouns: string;
  emotion: string;
  summary: string;
  diagnosis: string;
  conversation: {
    role: string;
    content: string;
  }[];
}

const BASE_URL = "http://73.47.65.103:5032"
const NOTES_URL = "/notes"

export default function TherapistNotesPage() {
  const [note, setNote] = useState<TherapistNote | null>(null);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const storedUserId = localStorage.getItem("user_id");
    if (storedUserId) {
      setUserId(storedUserId);
    } else {
      setError('No user ID found');
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const fetchNotes = async () => {
      if (!userId) return;

      try {
        setLoading(true);
        const response = await fetch(`${BASE_URL}${NOTES_URL}/${userId}`);
        
        if (!response.ok) {
          throw new Error('Failed to fetch notes');
        }
        
        const data = await response.json();
        setNote(data);
        setLoading(false);
      } catch (err) {
        console.error(err);
        setError('Failed to fetch therapist notes');
        setLoading(false);
      }
    };

    fetchNotes();
  }, [userId]);

  const handleDeleteConversation = async () => {
    window.location.href = "/delete_user"
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;
  if (!note) return <div>No notes found</div>;

  return (
    <div className="relative min-h-screen bg-[url(/images/img_group_12.png)] bg-cover bg-no-repeat p-6">
      <div className="container mx-auto">
        <Heading 
          as="h1" 
          className="text-shadow-ts text-center text-[6rem] font-black text-teal-300 mb-8 md:text-[3rem]"
        >
          Therapist Notes
        </Heading>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Patient Information Column */}
          <div className="space-y-6">
            <div>
              <Heading 
                as="h2" 
                className="font-kalam text-[2.5rem] font-bold text-deep_purple-800 mb-2 md:text-[2.38rem] sm:text-[2.25rem]"
              >
                Patient Name
              </Heading>
              <Input 
                value={note.name} 
                readOnly 
                shape="round"
                className="w-full rounded-lg border-[3px] border-gray-50_23 px-[0.75rem]"
              />
            </div>

            <div>
              <Heading 
                as="h3" 
                className="font-kalam text-[2.5rem] font-bold text-deep_purple-800 mb-2 md:text-[2.38rem] sm:text-[2.25rem]"
              >
                Pronouns
              </Heading>
              <Input 
                value={note.pronouns} 
                readOnly 
                shape="round"
                className="w-full rounded-lg border-[3px] border-gray-50_23 px-[0.75rem]"
              />
            </div>

            <div>
              <Heading 
                as="h3" 
                className="font-kalam text-[2.5rem] font-bold text-deep_purple-800 mb-2 md:text-[2.38rem] sm:text-[2.25rem]"
              >
                Mood Before Conversation
              </Heading>
              <Input 
                value={note.emotion} 
                readOnly 
                shape="round"
                className="w-full rounded-lg border-[3px] border-gray-50_23 px-[0.75rem]"
              />
            </div>

            <div>
              <Heading 
                as="h3" 
                className="font-kalam text-[2.5rem] font-bold text-deep_purple-800 mb-2 md:text-[2.38rem] sm:text-[2.25rem]"
              >
                Conversation Summary
              </Heading>
              <div className="w-full rounded-lg border-[3px] border-gray-50_23 p-3 min-h-[150px] bg-white overflow-y-auto max-h-[200px]">
                <p className="whitespace-pre-wrap">{note.summary}</p>
              </div>
            </div>

            <div>
              <Heading 
                as="h3" 
                className="font-kalam text-[2.5rem] font-bold text-deep_purple-800 mb-2 md:text-[2.38rem] sm:text-[2.25rem]"
              >
                Diagnosis
              </Heading>
              <div className="w-full rounded-lg border-[3px] border-gray-50_23 p-3 min-h-[150px] bg-white overflow-y-auto max-h-[200px]">
                <p className="whitespace-pre-wrap">{note.diagnosis}</p>
              </div>
            </div>
          </div>

          {/* Conversation Column */}
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <Heading 
                as="h2" 
                className="font-kalam text-[2.5rem] font-bold text-deep_purple-800 md:text-[2.38rem] sm:text-[2.25rem]"
              >
                Conversation
              </Heading>
              <Button 
                onClick={handleDeleteConversation}
                size="sm"
                shape="round"
                className="min-w-[18.25rem] rounded-[28px] border-2 px-[1.63rem] sm:px-[1.25rem] bg-red-500 text-white hover:bg-red-600"
              >
                Delete conversation
              </Button>
            </div>

            <div className="border-[3px] border-gray-50_23 rounded-lg p-4 bg-white max-h-[600px] overflow-y-auto">
              {note.conversation.map((message, index) => (
                <div 
                  key={index} 
                  className={`mb-4 p-3 rounded ${
                    message.role === 'assistant' 
                      ? 'bg-[#D1FAE5] text-[#0D9488]' 
                      : 'bg-[#EDE9FE] text-[#6D28D9]'
                  }`}
                >
                  <strong>{message.role === 'assistant' ? 'Therapist' : 'Patient'}:</strong>
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}