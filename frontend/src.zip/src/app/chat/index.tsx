import IMMessageComponent from "../../components/conversation";
export default function ChatPage() {


  return (
    <IMMessageComponent />
  );
}
